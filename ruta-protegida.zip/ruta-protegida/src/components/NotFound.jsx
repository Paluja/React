import React from 'react'

function NotFound() {
  return (
    <div>404 not found</div>
  )
}

export default NotFound